const uploadImage = require('../lib/uploadImage') 
const fetch = require('node-fetch')
const { sticker } = require('../lib/sticker')
const { MessageType } = require('@adiwajshing/baileys')

let handler = async (m, { conn, text }) => {
     let teks = text ? text : m.quoted && m.quoted.text ? m.quoted.text : m.text
     let url = await fetch(global.API('https://salism3api.pythonanywhere.com', '/text2img/',{text: teks, outlineColor : '255,0,0,255',textColor : '0,0,0,255'}))
     res = await url.json()
     stick = res.image
     let stiker = await sticker(null, stick, global.packname, global.author)
  conn.sendMessage(m.chat, stiker, MessageType.sticker, {
    quoted: m
  })
 } 
handler.help = ['bttp']
handler.tags = ['sticker']
handler.command = /^(bttp)$/i
handler.limit = true
//Made By Anshul
module.exports = handler