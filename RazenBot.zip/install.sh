pkg install nodejs -y
apt install ffmpeg -y
apt install imagemagick -y
npm install
npm update
npm audit fix
